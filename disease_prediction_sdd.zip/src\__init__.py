"""Disease prediction source package."""
